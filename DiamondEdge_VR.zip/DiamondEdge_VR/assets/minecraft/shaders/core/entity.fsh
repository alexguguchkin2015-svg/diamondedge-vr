#version 330
#extension GL_ARB_separate_shader_objects : require

#ifdef GLINT
#include <minecraft:globals.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
layout(location = 2) in vec4 vertexPerFaceColorBack;
layout(location = 3) in vec4 vertexPerFaceColorFront;
#else
layout(location = 2) in vec4 vertexColor;
#endif

#ifndef EMISSIVE
layout(location = 4) in vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
layout(location = 5) in vec4 overlayColor;
#endif

layout(location = 6) in vec2 texCoord0;
#ifdef GLINT
layout(location = 7) in vec2 texCoordGlint;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    #endif

    #ifndef EMISSIVE
    color *= lightMapColor;
    #endif

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);
    // Matches BlendFuntion.GLINT
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}

void main() {
    vec4 color = texture(Sampler0, texCoord0);

    #ifdef OIT_ADDITIVE
    color.a = min(0.99, color.a);
    #endif

    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    #ifdef PER_FACE_LIGHTING
    vec4 faceVertexColor = gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack;
    #else
    vec4 faceVertexColor = vertexColor;
    #endif

    #ifdef DISSOLVE
    if (faceVertexColor.a < texture(DissolveMaskSampler, texCoord0).a) {
        discard;
    }
    // The dissolve effect entirely replaces translucency
    faceVertexColor.a = 1.0;
    #endif

    color *= faceVertexColor * ColorModulator;

    #ifdef GLINT
    color.a = max(color.a, GlintAlpha);
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    // Переводим UV-координаты текстуры 64x64 в номера пикселей (от 0 до 63)
ivec2 pixel = ivec2(floor(texCoord0 * 64.0));

// Проверяем второй слой головы:
// Лицевая часть очков: x от 40 до 47, y от 11 до 13
// Правая дужка: x от 32 до 39, y от 11 до 12
// Левая дужка: x от 48 до 55, y от 11 до 12
// Ремешок сзади: x от 56 до 63, y == 11

// 1. Передний блок VR-очков (лицо)
if (pixel.x >= 40 && pixel.x <= 47 && pixel.y >= 11 && pixel.y <= 13) {
    // Внутренние линзы (x: 41..46, y: 11..12)
    if (pixel.x >= 41 && pixel.x <= 46 && pixel.y >= 11 && pixel.y <= 12) {
        // Неоново-алмазный экран линз с лёгким бликом
        if ((pixel.x == 42 || pixel.x == 45) && pixel.y == 11) {
            color = vec4(0.75, 0.98, 1.0, 1.0); // Светлый блик на стекле
        } else {
            color = vec4(0.10, 0.85, 0.95, 1.0); // Основной цвет экрана VR
        }
    } else {
        // Тёмно-графитовый корпус (оправа) очков по краям
        color = vec4(0.12, 0.14, 0.18, 1.0);
    }
}

// 2. Боковые дужки и ремешок по кругу головы (y == 11)
if (((pixel.x >= 32 && pixel.x <= 39) || (pixel.x >= 48 && pixel.x <= 63)) && pixel.y == 11) {
    color = vec4(0.15, 0.17, 0.22, 1.0); // Тёмный ремешок крепления
}
fragColor = calculateFinalColor(color);
    #endif
}
